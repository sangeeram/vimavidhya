<?php

$theme_uri = get_template_directory_uri();

$travel_page_data = [

    // -------------------------------------------------------------
    // SECTION 01.1: What is Travel Insurance?
    // -------------------------------------------------------------

    'section_1' => [

        'subtag'      => '01.1 — START HERE',

        'title'       => 'What Is Travel Insurance?',

        'description' => __(
            'Travel insurance is a contract between you and an insurance company where, in return for a relatively small premium, the insurer agrees to pay defined benefits if certain events disrupt or end your journey — whether that journey is from Delhi to Goa, or from Mumbai to Munich.',
            'vima-vidya'
        ),

        'covered_events' => [
            'title'   => 'The Core Events Travel Insurance Covers',
            'subtext' => 'Travel insurance activates during your trip to protect against unexpected financial losses that regular health and general policies are never designed to handle.',
            'cards'   => [
                [
                    'id'          => 'medical_emergency',
                    'label'       => 'Medical Emergency',
                    'tag'         => 'COVERED',
                    'icon'        => '🏥',
                    'explanation' => 'You fall ill or are injured during the trip requiring hospitalisation.',
                    'image'       => 'https://images.unsplash.com/photo-1584515979956-d9f6e5d09982?auto=format&fit=crop&w=600&q=80'
                ],
                [
                    'id'          => 'medical_evacuation',
                    'label'       => 'Medical Evacuation',
                    'tag'         => 'COVERED',
                    'icon'        => '🚁',
                    'explanation' => 'Local facilities cannot treat you; emergency transport to an adequately equipped hospital needed.',
                    'image'       => 'https://images.unsplash.com/photo-1516738901171-8eb4fc13bd20?auto=format&fit=crop&w=600&q=80'
                ],
                [
                    'id'          => 'trip_cancellation',
                    'label'       => 'Trip Cancellation',
                    'tag'         => 'COVERED',
                    'icon'        => '❌',
                    'explanation' => 'A covered event forces you to cancel before departure.',
                    'image'       => 'https://images.unsplash.com/photo-1488646953014-85cb44e25828?auto=format&fit=crop&w=600&q=80'
                ],
                [
                    'id'          => 'trip_delay',
                    'label'       => 'Trip Delay',
                    'tag'         => 'COVERED',
                    'icon'        => '⏱️',
                    'explanation' => 'Flight or train delayed beyond the threshold period.',
                    'image'       => 'https://images.unsplash.com/photo-1436491865332-7a61a109cc05?auto=format&fit=crop&w=600&q=80'
                ],
                [
                    'id'          => 'baggage_loss',
                    'label'       => 'Baggage Loss or Delay',
                    'tag'         => 'COVERED',
                    'icon'        => '🧳',
                    'explanation' => 'Checked baggage permanently lost or delayed beyond threshold.',
                    'image'       => 'https://images.unsplash.com/photo-1569154941061-e231b4725ef1?auto=format&fit=crop&w=600&q=80'
                ],
                [
                    'id'          => 'personal_accident',
                    'label'       => 'Personal Accident',
                    'tag'         => 'COVERED',
                    'icon'        => '⚡',
                    'explanation' => 'You die or suffer permanent disability in an accident during the trip.',
                    'image'       => 'https://images.unsplash.com/photo-1508672019048-805c876b67e2?auto=format&fit=crop&w=600&q=80'
                ]
            ]
        ],

        'not_covered_events' => [
            'title'   => 'What Travel Insurance is NOT',
            'subtext' => 'Travel insurance is not the same as your health insurance. It is not a duplicate of your Mediclaim policy. Health insurance covers your body every day of the year. Travel insurance activates only during the trip, covering unique risks your health insurer was never designed to handle.',
            'cards'   => [
                [
                    'id'          => 'health_duplicate',
                    'label'       => 'General Health Insurance',
                    'tag'         => 'NOT COVERED',
                    'icon'        => '🩺',
                    'explanation' => 'Routine year-round domestic medical care outside active trip dates.',
                    'image'       => 'https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?auto=format&fit=crop&w=600&q=80'
                ],
                [
                    'id'          => 'pre_existing',
                    'label'       => 'Undisclosed Pre-existing Illness',
                    'tag'         => 'NOT COVERED',
                    'icon'        => '📋',
                    'explanation' => 'Scheduled treatments or known chronic flare-ups ignored during policy signup.',
                    'image'       => 'https://images.unsplash.com/photo-1584515979956-d9f6e5d09982?auto=format&fit=crop&w=600&q=80'
                ],
                [
                    'id'          => 'reckless',
                    'label'       => 'Reckless & Extreme Sports',
                    'tag'         => 'NOT COVERED',
                    'icon'        => '🪂',
                    'explanation' => 'Unauthorised high-risk adventure activities without special endorsements.',
                    'image'       => 'https://images.unsplash.com/photo-1533587851505-d119e13fa0d7?auto=format&fit=crop&w=600&q=80'
                ],
                [
                    'id'          => 'war_risk',
                    'label'       => 'War & Civil Unrest',
                    'tag'         => 'NOT COVERED',
                    'icon'        => '🛡️',
                    'explanation' => 'Travel into active war zones or government-restricted conflict regions.',
                    'image'       => 'https://images.unsplash.com/photo-1541872703-74c5e44368f9?auto=format&fit=crop&w=600&q=80'
                ]
            ]
        ],

        'takeaway' => '<strong>Key Takeaway —</strong> Travel insurance pays for the trip that went wrong — delays, lost bags, overseas hospital bills, cancelled holidays, stolen passports. Your health insurance was never designed for these. Each product has its own territory. Travel insurance is the territory of the journey.'

    ],

    // -------------------------------------------------------------
    // SECTION 01.2: The Core Events Travel Insurance Covers (Interactive Stage)
    // -------------------------------------------------------------

    'section_2' => [

        'subtag'   => '01.2 — THE CORE EVENTS',

        'title'    => 'The Core Events Travel Insurance Covers',

        'subtitle' => 'An interactive breakdown of trip disruptions, medical contingencies, and financial protections.',

        'zones' => [
            'medical_emergency' => [
                'id'       => 'medical_emergency',
                'label'    => '1. Medical Emergency',
                'icon'     => '🏥',
                'image'    => $theme_uri . '/assets/images/typesofinsurance/travelinsurance/understand/what-can-it-protect-1.png',
                'badge'    => 'Medical Support',
                'title'    => 'Medical Emergency Cover',
                'desc'     => 'Covers sudden illnesses or accidental injuries requiring hospitalisation while away from home.',
                'includes' => [
                    'Hospitalisation bills',
                    'Doctor consultation fees',
                    'Prescribed medicines',
                    'Emergency ambulance'
                ],
                'who_for'  => ['International Travelers', 'Domestic Voyagers'],
                'best_for' => 'Anyone traveling away from home city or overseas',
                'protects_against' => [
                    '🏥 Sudden illness requiring admission',
                    '🚑 Accident injury medical treatment'
                ],
                'pins'     => [
                    ['label' => 'Hospital Care', 'top' => '45%', 'left' => '50%'],
                    ['label' => 'Emergency Treatment', 'top' => '70%', 'left' => '30%']
                ]
            ],
            'medical_evacuation' => [
                'id'       => 'medical_evacuation',
                'label'    => '2. Medical Evacuation',
                'icon'     => '🚁',
                'image'    => $theme_uri . '/assets/images/typesofinsurance/travelinsurance/understand/what-can-it-protect-2.png',
                'badge'    => 'Emergency Transport',
                'title'    => 'Medical Evacuation Cover',
                'desc'     => 'Arranges and funds emergency transport when local medical facilities cannot adequately treat your condition.',
                'includes' => [
                    'Air ambulance services',
                    'Stretcher transport',
                    'Escort medical staff',
                    'Transfer to home country'
                ],
                'who_for'  => ['Remote & Overseas Travelers'],
                'best_for' => 'Travelers visiting remote destinations or international regions',
                'protects_against' => [
                    '🚁 Lack of local medical infrastructure',
                    '⚡ Critical transport requirements'
                ],
                'pins'     => [
                    ['label' => 'Air Ambulance', 'top' => '30%', 'left' => '45%']
                ]
            ],
            'trip_cancellation' => [
                'id'       => 'trip_cancellation',
                'label'    => '3. Trip Cancellation',
                'icon'     => '❌',
                'image'    => $theme_uri . '/assets/images/typesofinsurance/travelinsurance/understand/what-can-it-protect-3.png',
                'badge'    => 'Pre-Departure Protection',
                'title'    => 'Trip Cancellation Cover',
                'desc'     => 'Reimburses non-refundable prepaid travel expenses if a covered event forces you to cancel before departure.',
                'includes' => [
                    'Prepaid flight tickets',
                    'Hotel booking deposits',
                    'Tour operator fees',
                    'Event ticket refunds'
                ],
                'who_for'  => ['Pre-booked Holidaymakers'],
                'best_for' => 'Travelers with heavy advance bookings and non-refundable deposits',
                'protects_against' => [
                    '❌ Sudden illness prior to departure',
                    '🌪️ Severe weather cancellations'
                ],
                'pins'     => [
                    ['label' => 'Advance Bookings', 'top' => '50%', 'left' => '55%']
                ]
            ],
            'trip_delay' => [
                'id'       => 'trip_delay',
                'label'    => '4. Trip Delay & Interruption',
                'icon'     => '⏱️',
                'image'    => $theme_uri . '/assets/images/typesofinsurance/travelinsurance/understand/what-can-it-protect-4.png',
                'badge'    => 'Transit Protection',
                'title'    => 'Trip Delay & Interruption Cover',
                'desc'     => 'Compensates meal and lodging expenses during extended flight delays or covers emergency return ticket costs.',
                'includes' => [
                    'Meal allowances',
                    'Hotel accommodation',
                    'Emergency return tickets',
                    'Unused prepaid days'
                ],
                'who_for'  => ['Frequent Flyers', 'Tourists'],
                'best_for' => 'Anyone facing long-haul flight connections and transit schedules',
                'protects_against' => [
                    '⏱️ Airline scheduling delays',
                    '🔄 Early emergency return home'
                ],
                'pins'     => [
                    ['label' => 'Transit Lounge', 'top' => '40%', 'left' => '40%']
                ]
            ],
            'baggage_loss' => [
                'id'       => 'baggage_loss',
                'label'    => '5. Baggage & Liability',
                'icon'     => '🧳',
                'image'    => $theme_uri . '/assets/images/typesofinsurance/travelinsurance/understand/what-can-it-protect-5.png',
                'badge'    => 'Belongings & Liability',
                'title'    => 'Baggage Loss & Personal Liability',
                'desc'     => 'Protects against permanently lost checked luggage or legal liabilities if you accidentally injure a third party.',
                'includes' => [
                    'Replacement compensation',
                    'Emergency clothing purchases',
                    'Passport replacement aid',
                    'Third-party legal liability'
                ],
                'who_for'  => ['All Travelers'],
                'best_for' => 'Travelers carrying valuables or checking luggage on airlines',
                'protects_against' => [
                    '🧳 Checked baggage loss',
                    '⚖️ Accidental third-party injury'
                ],
                'pins'     => [
                    ['label' => 'Luggage Claim', 'top' => '55%', 'left' => '48%']
                ]
            ]
        ],

        'takeaway' => '<strong>Key Takeaway:</strong> Travel insurance is tailored specifically around the journey timeline. Whether you are dealing with canceled flights, lost luggage, or unexpected overseas clinic visits, coverage ensures financial security from departure until you return home.'

    ]

];
?>

<div class="vv-travel-insurance-wrapper" id="travel-what-it-is">

    <!-- SECTION 01.1 -->
    <section class="vv-travel-insurance-section-s1">
        <header class="vv-travel-insurance-header">
            <span class="vv-travel-insurance-subtag"><?php echo esc_html($travel_page_data['section_1']['subtag']); ?></span>
            <h1 class="vv-travel-insurance-title"><?php echo esc_html($travel_page_data['section_1']['title']); ?></h1>
            <p class="vv-travel-insurance-desc"><?php echo wp_kses_post($travel_page_data['section_1']['description']); ?></p>
        </header>

        <div class="vv-travel-insurance-contrast-grid">
            <!-- Covered Column -->
            <section class="vv-travel-insurance-contrast-col vv-travel-insurance-contrast-col--covered">
                <div class="vv-travel-insurance-col-header">
                    <div class="vv-travel-insurance-col-icon-circle vv-travel-insurance-col-icon-circle--covered">
                        <svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg>
                    </div>
                    <div class="vv-travel-insurance-col-title-wrap">
                        <h2 class="vv-travel-insurance-col-title"><?php echo esc_html($travel_page_data['section_1']['covered_events']['title']); ?></h2>
                        <span class="vv-travel-insurance-col-underline vv-travel-insurance-col-underline--covered"></span>
                    </div>
                </div>
                <p class="vv-travel-insurance-col-subtext"><?php echo wp_kses_post($travel_page_data['section_1']['covered_events']['subtext']); ?></p>

                <div class="vv-travel-insurance-peril-card-grid">
                    <?php foreach ($travel_page_data['section_1']['covered_events']['cards'] as $card): ?>
                    <article class="vv-travel-insurance-visual-card vv-travel-insurance-visual-card--covered">
                        <div class="vv-travel-insurance-visual-card__media">
                            <img src="<?php echo esc_url($card['image']); ?>" alt="<?php echo esc_attr($card['label']); ?>" loading="lazy">
                            <span class="vv-travel-insurance-visual-card__pill"><?php echo esc_html($card['tag']); ?></span>
                        </div>
                        <div class="vv-travel-insurance-visual-card__body">
                            <span class="vv-travel-insurance-visual-card__icon-badge"><?php echo esc_html($card['icon']); ?></span>
                            <h3 class="vv-travel-insurance-visual-card__title"><?php echo esc_html($card['label']); ?></h3>
                            <p class="vv-travel-insurance-visual-card__desc"><?php echo esc_html($card['explanation']); ?></p>
                        </div>
                    </article>
                    <?php endforeach; ?>
                </div>
            </section>

            <!-- Not Covered Column -->
            <section class="vv-travel-insurance-contrast-col vv-travel-insurance-contrast-col--denied">
                <div class="vv-travel-insurance-col-header">
                    <div class="vv-travel-insurance-col-icon-circle vv-travel-insurance-col-icon-circle--denied">
                        <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
                    </div>
                    <div class="vv-travel-insurance-col-title-wrap">
                        <h2 class="vv-travel-insurance-col-title"><?php echo esc_html($travel_page_data['section_1']['not_covered_events']['title']); ?></h2>
                        <span class="vv-travel-insurance-col-underline vv-travel-insurance-col-underline--denied"></span>
                    </div>
                </div>
                <p class="vv-travel-insurance-col-subtext"><?php echo wp_kses_post($travel_page_data['section_1']['not_covered_events']['subtext']); ?></p>

                <div class="vv-travel-insurance-peril-card-grid">
                    <?php foreach ($travel_page_data['section_1']['not_covered_events']['cards'] as $card): ?>
                    <article class="vv-travel-insurance-visual-card vv-travel-insurance-visual-card--denied">
                        <div class="vv-travel-insurance-visual-card__media">
                            <img src="<?php echo esc_url($card['image']); ?>" alt="<?php echo esc_attr($card['label']); ?>" loading="lazy">
                            <span class="vv-travel-insurance-visual-card__pill"><?php echo esc_html($card['tag']); ?></span>
                        </div>
                        <div class="vv-travel-insurance-visual-card__body">
                            <span class="vv-travel-insurance-visual-card__icon-badge"><?php echo esc_html($card['icon']); ?></span>
                            <h3 class="vv-travel-insurance-visual-card__title"><?php echo esc_html($card['label']); ?></h3>
                            <p class="vv-travel-insurance-visual-card__desc"><?php echo esc_html($card['explanation']); ?></p>
                        </div>
                    </article>
                    <?php endforeach; ?>
                </div>
            </section>
        </div>

        <aside class="vv-travel-insurance-global-takeaway vv-travel-insurance-global-takeaway--s1">
            <span class="vv-travel-insurance-global-takeaway__icon" aria-hidden="true">💡</span>
            <p class="vv-travel-insurance-global-takeaway__text"><?php echo wp_kses_post($travel_page_data['section_1']['takeaway']); ?></p>
        </aside>
    </section>

    <!-- SECTION 01.2: INTERACTIVE STAGE SPLIT -->
    <section class="vv-travel-insurance-section-s2">
        <header class="vv-travel-insurance-header vv-travel-insurance-header--secondary">
            <span class="vv-travel-insurance-subtag"><?php echo esc_html($travel_page_data['section_2']['subtag']); ?></span>
            <h2 class="vv-travel-insurance-title-h2"><?php echo esc_html($travel_page_data['section_2']['title']); ?></h2>
            <p class="vv-travel-insurance-desc"><?php echo esc_html($travel_page_data['section_2']['subtitle']); ?></p>
        </header>

        <div class="vv-travel-insurance-stage-wrapper">
            <nav class="vv-travel-insurance-layer-timeline" role="tablist" aria-label="Travel Coverage Stages">
                <?php foreach ($travel_page_data['section_2']['zones'] as $key => $zone): ?>
                <button type="button" role="tab"
                    class="vv-travel-insurance-layer-step <?php echo $key === 'medical_emergency' ? 'is-active' : ''; ?>"
                    data-layer="<?php echo esc_attr($key); ?>"
                    aria-selected="<?php echo $key === 'medical_emergency' ? 'true' : 'false'; ?>">
                    <span class="vv-travel-insurance-layer-step__icon"><?php echo esc_html($zone['icon']); ?></span>
                    <span class="vv-travel-insurance-layer-step__label"><?php echo esc_html($zone['label']); ?></span>
                </button>
                <?php endforeach; ?>
            </nav>

            <div class="vv-travel-insurance-stage-split">
                <!-- VIEWPORT -->
                <div class="vv-travel-insurance-viewport vv-travel-insurance-viewport--compact" id="vvTravelInsuranceViewport">
                    <img id="vvTravelInsuranceStageImage" class="vv-travel-insurance-stage-img"
                        src="<?php echo esc_url($travel_page_data['section_2']['zones']['medical_emergency']['image']); ?>"
                        alt="Travel Insurance Stage View">
                    <div class="vv-travel-insurance-viewport__overlay">
                        <span class="vv-travel-insurance-layer-badge" id="vvTravelInsuranceLayerBadge">
                            <?php echo esc_html($travel_page_data['section_2']['zones']['medical_emergency']['badge']); ?>
                        </span>
                    </div>
                    <div id="vvTravelInsurancePinContainer" class="vv-travel-insurance-pin-container"></div>
                </div>

                <!-- SIDE PANEL -->
                <div class="vv-travel-insurance-side-panel vv-travel-insurance-side-panel--compact" id="vvTravelInsuranceSidePanel">
                    <div class="vv-travel-insurance-panel-header">
                        <span class="vv-travel-insurance-panel-icon" id="vvTravelInsurancePanelIcon">
                            <?php echo esc_html($travel_page_data['section_2']['zones']['medical_emergency']['icon']); ?>
                        </span>
                        <div>
                            <span class="vv-travel-insurance-panel-sub">Coverage Details</span>
                            <h3 class="vv-travel-insurance-panel-title" id="vvTravelInsurancePanelTitle">
                                <?php echo esc_html($travel_page_data['section_2']['zones']['medical_emergency']['title']); ?>
                            </h3>
                        </div>
                    </div>

                    <div class="vv-travel-insurance-panel-body">
                        <p class="vv-travel-insurance-panel-desc" id="vvTravelInsurancePanelDesc">
                            <?php echo esc_html($travel_page_data['section_2']['zones']['medical_emergency']['desc']); ?>
                        </p>

                        <div class="vv-travel-insurance-panel-group vv-travel-insurance-panel-group--merged">
                            <span class="vv-travel-insurance-panel-group-title">Who & Best For</span>
                            <div class="vv-travel-insurance-merged-audience-content">
                                <p class="vv-travel-insurance-panel-best-for" id="vvTravelInsurancePanelBestFor">
                                    <?php echo esc_html($travel_page_data['section_2']['zones']['medical_emergency']['best_for']); ?>
                                </p>
                            </div>
                        </div>

                        <div class="vv-travel-insurance-panel-grid-row">
                            <div class="vv-travel-insurance-panel-group vv-travel-insurance-panel-group--no-border">
                                <span class="vv-travel-insurance-panel-group-title">Includes</span>
                                <ul class="vv-travel-insurance-panel-list" id="vvTravelInsurancePanelIncludes">
                                    <?php foreach ($travel_page_data['section_2']['zones']['medical_emergency']['includes'] as $inc): ?>
                                    <li>
                                        <span class="vv-travel-include-icon" aria-hidden="true">✓</span>
                                        <span><?php echo esc_html($inc); ?></span>
                                    </li>
                                    <?php endforeach; ?>
                                </ul>
                            </div>

                            <div class="vv-travel-insurance-panel-group vv-travel-insurance-panel-group--no-border">
                                <span class="vv-travel-insurance-panel-group-title">When It Protects</span>
                                <ul class="vv-travel-insurance-panel-list" id="vvTravelInsurancePanelProtects">
                                    <?php foreach ($travel_page_data['section_2']['zones']['medical_emergency']['protects_against'] as $item): ?>
                                    <li><?php echo esc_html($item); ?></li>
                                    <?php endforeach; ?>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <aside class="vv-travel-insurance-global-takeaway vv-travel-insurance-global-takeaway--s2">
            <span class="vv-travel-insurance-global-takeaway__icon" aria-hidden="true">✅</span>
            <p class="vv-travel-insurance-global-takeaway__text"><?php echo wp_kses_post($travel_page_data['section_2']['takeaway']); ?></p>
        </aside>
    </section>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const zonesData = <?php echo json_encode($travel_page_data['section_2']['zones'], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE); ?>;
    let activeZoneKey = 'medical_emergency';

    const imgEl = document.getElementById('vvTravelInsuranceStageImage');
    const badgeEl = document.getElementById('vvTravelInsuranceLayerBadge');
    const pinContainer = document.getElementById('vvTravelInsurancePinContainer');
    const timelineButtons = document.querySelectorAll('.vv-travel-insurance-layer-step');

    const panelIcon = document.getElementById('vvTravelInsurancePanelIcon');
    const panelTitle = document.getElementById('vvTravelInsurancePanelTitle');
    const panelDesc = document.getElementById('vvTravelInsurancePanelDesc');
    const panelBestFor = document.getElementById('vvTravelInsurancePanelBestFor');
    const panelIncludes = document.getElementById('vvTravelInsurancePanelIncludes');
    const panelProtects = document.getElementById('vvTravelInsurancePanelProtects');

    function renderPins(pins) {
        if (!pinContainer) return;
        pinContainer.innerHTML = '';
        if (!Array.isArray(pins)) return;

        pins.forEach(function(pin, index) {
            const btn = document.createElement('button');
            btn.type = 'button';
            btn.className = 'vv-travel-insurance-map-pin';
            btn.style.top = pin.top || '50%';
            btn.style.left = pin.left || '50%';
            btn.textContent = pin.label || '';
            pinContainer.appendChild(btn);
        });
    }

    function updateDetailsPanel(data) {
        if (!data) return;
        if (panelIcon) panelIcon.textContent = data.icon || '';
        if (panelTitle) panelTitle.textContent = data.title || '';
        if (panelDesc) panelDesc.textContent = data.desc || '';
        if (panelBestFor) panelBestFor.textContent = data.best_for || '';

        if (panelIncludes) {
            panelIncludes.innerHTML = '';
            if (Array.isArray(data.includes)) {
                data.includes.forEach(function(item) {
                    const li = document.createElement('li');
                    const icon = document.createElement('span');
                    icon.className = 'vv-travel-include-icon';
                    icon.textContent = '✓';
                    icon.setAttribute('aria-hidden', 'true');

                    const label = document.createElement('span');
                    label.textContent = item;

                    li.appendChild(icon);
                    li.appendChild(label);
                    panelIncludes.appendChild(li);
                });
            }
        }

        if (panelProtects) {
            panelProtects.innerHTML = '';
            if (Array.isArray(data.protects_against)) {
                data.protects_against.forEach(function(item) {
                    const li = document.createElement('li');
                    li.textContent = item;
                    panelProtects.appendChild(li);
                });
            }
        }
    }

    function switchLayer(key) {
        if (!zonesData || !zonesData[key] || key === activeZoneKey) return;
        activeZoneKey = key;
        const data = zonesData[key];

        timelineButtons.forEach(function(btn) {
            const isActive = btn.getAttribute('data-layer') === key;
            btn.classList.toggle('is-active', isActive);
            btn.setAttribute('aria-selected', isActive ? 'true' : 'false');
        });

        if (imgEl) {
            imgEl.classList.add('is-switching');
            setTimeout(function() {
                imgEl.src = data.image;
                if (badgeEl) badgeEl.textContent = data.badge;
                renderPins(data.pins);
                imgEl.onload = function() {
                    imgEl.classList.remove('is-switching');
                };
            }, 150);
        }

        updateDetailsPanel(data);
    }

    if (timelineButtons.length) {
        timelineButtons.forEach(function(btn) {
            btn.addEventListener('click', function() {
                switchLayer(this.getAttribute('data-layer'));
            });
        });
    }

    if (zonesData.medical_emergency) {
        renderPins(zonesData.medical_emergency.pins);
    }
});
</script>