<?php
// health-why-it-matters.php
?>
<section class="health-case-for-cover" id="health-why-it-matters">
    <div class="health-case-for-cover__container">

        <!-- Section Header -->
        <header class="health-case-for-cover__header">
            <h2 class="health-case-for-cover__title">Why You Need Health Insurance Today</h2>
            <p class="health-case-for-cover__subtitle">
                The best time to buy health insurance is when you are young and healthy. The second-best time is right now.
            </p>
        </header>

        <!-- Carousel Container with Side Buttons -->
        <div class="health-case-for-cover__carousel-wrapper">
            
            <!-- Previous Button -->
            <button class="health-case-for-cover__nav-btn health-case-for-cover__nav-btn--prev" id="health-prev-btn" aria-label="Previous Slide">
                <svg viewBox="0 0 24 24"><polyline points="15 18 9 12 15 6"></polyline></svg>
            </button>

            <!-- Scrollable Viewport -->
            <div class="health-case-for-cover__carousel-viewport" id="health-carousel-viewport">
                <div class="health-case-for-cover__grid">
                    
                    <!-- Card 1: Rising Medical Costs -->
                    <div class="health-case-for-cover__card">
                        <div class="health-case-for-cover__card-icon">🏥</div>
                        <span class="health-case-for-cover__card-badge">Reason 01</span>
                        <h3 class="health-case-for-cover__card-title">Rising Medical Costs</h3>
                        <p class="health-case-for-cover__text">
                            Healthcare inflation in India runs at 14–15% annually — double the general CPI. A hospitalisation that costs ₹3 lakh today could cost ₹10 lakh in ten years.
                        </p>
                    </div>

                    <!-- Card 2: Protect Your Savings -->
                    <div class="health-case-for-cover__card">
                        <div class="health-case-for-cover__card-icon">💰</div>
                        <span class="health-case-for-cover__card-badge">Reason 02</span>
                        <h3 class="health-case-for-cover__card-title">Protect Your Savings</h3>
                        <p class="health-case-for-cover__text">
                            A single major illness can wipe out years of savings. Insurance is your financial firewall — so a health crisis does not become a financial one.
                        </p>
                    </div>

                    <!-- Card 3: Access Quality Care -->
                    <div class="health-case-for-cover__card">
                        <div class="health-case-for-cover__card-icon">🏨</div>
                        <span class="health-case-for-cover__card-badge">Reason 03</span>
                        <h3 class="health-case-for-cover__card-title">Access Quality Care</h3>
                        <p class="health-case-for-cover__text">
                            Cashless cover at network hospitals lets you choose better facilities without worrying about bills at the counter.
                        </p>
                    </div>

                    <!-- Card 4: Peace of Mind -->
                    <div class="health-case-for-cover__card">
                        <div class="health-case-for-cover__card-icon">🧘</div>
                        <span class="health-case-for-cover__card-badge">Reason 04</span>
                        <h3 class="health-case-for-cover__card-title">Peace of Mind</h3>
                        <p class="health-case-for-cover__text">
                            Knowing you are covered lets you focus on recovery, not finances, during an already stressful time.
                        </p>
                    </div>

                    <!-- Card 5: Waiting Periods Apply -->
                    <div class="health-case-for-cover__card">
                        <div class="health-case-for-cover__card-icon">📋</div>
                        <span class="health-case-for-cover__card-badge">Reason 05</span>
                        <h3 class="health-case-for-cover__card-title">Waiting Periods Apply</h3>
                        <p class="health-case-for-cover__text">
                            Most policies have 2–4 year waiting periods for pre-existing diseases. Starting early means being fully covered when it matters most.
                        </p>
                    </div>

                    <!-- Card 6: Tax Benefit — Section 80D -->
                    <div class="health-case-for-cover__card">
                        <div class="health-case-for-cover__card-icon">💸</div>
                        <span class="health-case-for-cover__card-badge">Reason 06</span>
                        <h3 class="health-case-for-cover__card-title">Tax Benefit — Section 80D</h3>
                        <p class="health-case-for-cover__text">
                            Premiums qualify for deductions up to ₹25,000 (₹50,000–₹75,000 if covering senior citizen parents).
                        </p>
                    </div>

                    <!-- Card 7: Employer Cover Is Not Enough -->
                    <div class="health-case-for-cover__card">
                        <div class="health-case-for-cover__card-icon">🔄</div>
                        <span class="health-case-for-cover__card-badge">Reason 07</span>
                        <h3 class="health-case-for-cover__card-title">Employer Cover Is Not Enough</h3>
                        <p class="health-case-for-cover__text">
                            Group cover ends with your job, carries low sum insured, and rarely covers your family post-retirement.
                        </p>
                    </div>

                </div>
            </div>

            <!-- Next Button -->
            <button class="health-case-for-cover__nav-btn health-case-for-cover__nav-btn--next" id="health-next-btn" aria-label="Next Slide">
                <svg viewBox="0 0 24 24"><polyline points="9 18 15 12 9 6"></polyline></svg>
            </button>

        </div>

    </div>
</section>

<script>
document.addEventListener("DOMContentLoaded", function () {
    const viewport = document.getElementById("health-carousel-viewport");
    const prevBtn = document.getElementById("health-prev-btn");
    const nextBtn = document.getElementById("health-next-btn");

    if (viewport && prevBtn && nextBtn) {
        // Scroll distance equals one card width plus gap (320px + 24px = 344px)
        const scrollAmount = 344;

        prevBtn.addEventListener("click", () => {
            viewport.scrollBy({ left: -scrollAmount, behavior: "smooth" });
        });

        nextBtn.addEventListener("click", () => {
            viewport.scrollBy({ left: scrollAmount, behavior: "smooth" });
        });
    }
});
</script>